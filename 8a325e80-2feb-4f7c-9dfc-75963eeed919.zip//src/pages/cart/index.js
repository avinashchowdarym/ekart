import CartPage from "./CartPage";

export default CartPage;
