import PauseOnHover from "./Slide";
export default PauseOnHover;
