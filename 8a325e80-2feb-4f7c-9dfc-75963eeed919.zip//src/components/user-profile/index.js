import UserProfile from "./UserProfile";

export default UserProfile;
